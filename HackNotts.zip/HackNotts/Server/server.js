const express = require('express');

const apiRouter = require('./route');

const app = express();

app.use(express.json());

app.use('/api/chirps', apiRouter);

app.listen(process.env.PORT || '3306', () => {

    console.log(`Server is running on port: ${process.env.PORT || '3306'}`);

});