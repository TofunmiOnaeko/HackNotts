const mysql = require('mysql');

const pool = mysql.createPool({
connectionLimit: 15,
password: '1CabsAkin|Phi',
user: 'b2054682',
database: 'b2054682',
host: 'cs-db.ncl.ac.uk',
port: '3306'
});

let b2054682db = {};

b2054682db.all = () => {

    return new Promise((resolve, reject) => {

        pool.query(`SELECT * FROM ArcadeAngel`, (err, result) => {
            //parse.json

            if(err){
                return reject(err);
            }

            return resolve(results)

        });

    });

};

module.exports = b2054682db;